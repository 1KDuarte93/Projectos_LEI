/*Os_Accepted*/
#include "estruturas.h"

void find_expr(symbol_table *tlocal, symbol_table *tglobal, Node *node);
char *add_type(symbol_table *tlocal, symbol_table *tglobal, Node *node);
char *calls_type(symbol_table *tlocal, symbol_table *tglobal, Node *node);
char *search_vartype(Node *no);
char *search_idtype(symbol_table *gtable, symbol_table *ltable, Node *node);
symbol_table *search_ltable(symbol_table *gtable, char *name);
char* cat_type(Node *no, char *tipo);
char *delete_ast(char *str);
int count_child_deref(Node *no);
int find_lsq(char *tipo);
char *cmp_type(char *type1, char *type2, char *op); /*modificar*/
char *pointer_count(char *str1, char *str2);
int calcula_tamanho_strlit(char * strlit);
int check_chrlit_number(char numero);
char *addr_type(symbol_table *tlocal, symbol_table *tglobal, Node *node);
char *deref_type(symbol_table *tlocal, symbol_table *tglobal, Node *node);
char *comp_op(symbol_table *tlocal, symbol_table *tglobal, Node *node);
char *unary_op(symbol_table *tlocal, symbol_table *tglobal, Node *node);