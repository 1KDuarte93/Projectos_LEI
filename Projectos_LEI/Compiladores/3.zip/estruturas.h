/*Os_Accepted*/
#ifndef ESTR_H
#define ESTR_H

typedef struct Node Node;
typedef struct param_type param_type;
typedef struct symbol_element symbol_element;
typedef struct symbol_table symbol_table;
typedef struct lex_to_yacc lex_to_yacc;

struct Node{
	char *node_type;
	char *value;
	char *type;
	symbol_element *symbol_declaration;
	Node *child;
	Node *brother;
	int op_term, linha, coluna; /*1-op, 2-term*/
};

struct lex_to_yacc{
	char *str;
	int linha, coluna;
};

struct param_type{
	char *type_name;
	param_type *next;
};

struct symbol_element{
	char *name;
	char *type;
	param_type *paramtype;
	int param;
	symbol_element *next;
};

struct symbol_table{
	char *title;
	int definition;
	symbol_table *next;
	symbol_element *symbol;
};

#endif
