/*Os_Accepted*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "errors.h"
#include "estruturas.h"
#include "tabela_simbolos.h"

int check_lvalue(Node * node, symbol_table *tlocal, symbol_table *tglobal){ /*node = Store->child*/
	Node *tmp;
	if(strcmp(node->node_type, "Deref")==0){
		tmp = node;
		while(strcmp(node->node_type, "Deref")==0)
			tmp = tmp->child;
		if(!(tmp->node_type[0] == 'I' && tmp->node_type[1] == 'd') && strcmp(tmp->node_type, "Add")!=0 ){ /*é ID*/
			printf("Line %d, col %d: Lvalue required\n", node->child->linha, node->child->coluna);
		}
	}

	if(!(node->node_type[0] == 'I' && node->node_type[1] == 'd')){
		printf("Line %d, col %d: Lvalue required\n", node->linha, node->coluna);
		node->type = (char*)malloc(6);
		strcpy(node->type, "undef");
		return 1;
	}
	return 0;
}

int check_conftypes(char *type1, char *type2, Node *node){
	if(strcmp(type1, type2)==0){
		/*
		printf("Line %d, col %d: Conflicting types (got %s, expected %s)\n", node->linha, node->coluna, type1, type2);
		return 1;*/
		return 0;
	}
	return 0;
}

int check_call(Node *node){ /*recebe: Call*/
	char *call_name;
	Node *node_tmp;
	int i, j;
	param_type *element_tmp;

	call_name = node->child->value;
	element_tmp = node->child->symbol_declaration->paramtype; /*1o tipo*/
	node_tmp = node->child->brother; /*1a var*/

	/*check numero de parametros*/
	for(i=0; element_tmp!= NULL; element_tmp = element_tmp->next, i++);
	for(j=0; node_tmp!= NULL; node_tmp=node_tmp->brother, j++);
	if(i != j){
		printf("Line %d, col %d: Wrong number of arguments to function %s (got %d, required %d)\n", node->child->linha, node->child->coluna, call_name, j, i);
		return 1;
	}else{
		/*check tipos de parametros*/
		element_tmp = node->child->symbol_declaration->paramtype; /*1o tipo*/
		node_tmp = node->child->brother; /*1a var*/
		for(j=0; j<i; j++, element_tmp=element_tmp->next, node_tmp=node_tmp->brother){
			if(strcmp(element_tmp->type_name, node_tmp->type)!= 0){
				/*printf("Line %d, col %d: Conflicting types (got %s, expected %s)\n", node_tmp->linha, node_tmp->coluna, node_tmp->type, element_tmp->type_name);
				return 1;*/
				return 0;
			}
		}
	}
	return 0;
}

void is_not_func(Node* no){
	printf("Line %d, col %d: Symbol %s is not a function\n", no->linha, no->coluna, no->value);
}

int is_defined(Node *node, symbol_table *gtable, symbol_table *ltable, char *type){ /*se ltable==NULL ->estamos na global*/
	char *var_name;
	symbol_element *tmp_symbol;

	if(node == NULL) return 1;
	var_name = node->value;

	/*LOCAL*/
	if(ltable != NULL){
		tmp_symbol = ltable->symbol;
		while(tmp_symbol != NULL){
			if(strcmp(tmp_symbol->name, var_name)==0){
				printf("Line %d, col %d: Symbol %s already defined\n", node->linha, node->coluna, node->value);
				return 1;
			}
			tmp_symbol = tmp_symbol->next;
		}
		return 0;
	}
	
	tmp_symbol = gtable->symbol;

	/*GLOBAL*/
	while(tmp_symbol != NULL){
		if(strcmp(tmp_symbol->name, var_name)==0 && strcmp(tmp_symbol->type, type)!=0){ /*Se nome == e tipo !=*/
			printf("Line %d, col %d: Symbol %s already defined\n", node->linha, node->coluna, node->value);
			return 1;
		}
		else if(strcmp(tmp_symbol->name, var_name)==0 && strcmp(tmp_symbol->type, type)==0){ /*mesma var, mesmo tipo*/
			return 1;
		}
		tmp_symbol = tmp_symbol->next;
	}
	return 0;
}

char *unknown_symbol(Node *no){
	printf("Line %d, col %d: Unknown symbol %s\n", no->linha, no->coluna, no->value);
	no->type = (char*)malloc(6);
	strcpy(no->type, "undef");
	return no->type;
}

int check_void(char *type, Node *id){
	if(id == NULL){
		return 0;
	}
	else if(strcmp(type, "void")==0){
		printf("Line %d, col %d: Invalid use of void type in declaration\n", id->linha, id->coluna);
		return 1;
	}
	return 0;
}

int check_valid_operator_unarios(char *no_operador, char * type){
	if(strcmp(no_operador, "Minus") == 0){
		if(strcmp(type, "StrLit") == 0){
			printf("ERRROR \n");
			return 1;
		}else if(strcmp(type, "Void") == 0){
			printf("ERRO \n");
			return 1;
		}
	}
	return 0;
}

/*int valid_array_or_var(Node *no, symbol_table *tlocal, symbol_table *tglobal){ no = no depois do ultimo deref
	Node *tmp;
	tmp = no;
	if(tmp->child != NULL && tmp->op_term == 1){
		valid_array_or_var(tmp, tlocal, tglobal);
	}
	
}*/


int invalid_use_void_decl(Node *id_func){
	Node *tmp_node;
	char *strtype;
	tmp_node = id_func->brother->child; /*Paramlist->Paramdeclaration (existe sempre)*/
	/*verificar o habitual int main(void);*/

	if(tmp_node->brother == NULL){ /*so 1 parametro*/

		tmp_node = add_str_pointer(&strtype, tmp_node->child); /*tmp node é id ou NULL*/
		if(strcmp(strtype, "void") == 0 && tmp_node != NULL){
			printf("Line %d, col %d: Invalid use of void type in declaration\n", id_func->linha, id_func->coluna);
			return 1;
		}
		free(strtype);
		return 0;
	}
	while(tmp_node != NULL && strcmp(tmp_node->node_type, "ParamDeclaration")==0){
		add_str_pointer(&strtype, tmp_node->child);
		if(strcmp(strtype, "void") == 0){
			printf("Line %d, col %d: Invalid use of void type in declaration\n", id_func->linha, id_func->coluna);
			return 1;
		}
		free(strtype);
		tmp_node = tmp_node->brother;
	}
	return 0;
}

/*chekar repeticao de declaracao de parametros*/
int check_params(Node *paramlist_node){
	Node *tmp1;
	Node *tmp_node;
	param_type *tmp_paramlist = NULL;
	tmp_node = paramlist_node->child;
	while(tmp_node != NULL){ /**/
		/*encontrar id*/
		tmp1 = tmp_node->child;
		while(tmp1->brother != NULL)
			tmp1 = tmp1->brother;
		/*tmp1 ou é id ou é pointer*/
		if(tmp1->node_type[0] == 'I' && tmp1->node_type[1] == 'd'){ /*nao e pointer, e ID*/
			while(tmp_paramlist != NULL){
				if(strcmp(tmp_paramlist->type_name, tmp1->value)==0){ /*existe parametro com var igual!!*/
					printf("Line %d, col %d: Symbol %s already defined\n", tmp1->linha, tmp1->coluna, tmp1->value);
					 /*free*/
					return 1;
				}
				tmp_paramlist = tmp_paramlist->next;
			}
			tmp_paramlist = add_entry_param(tmp_paramlist, tmp1->value);
		}

		tmp_node = tmp_node->brother;
	}
	/*free*/
	return 0;
}