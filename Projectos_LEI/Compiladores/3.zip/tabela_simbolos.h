/*Os_Accepted*/
#include "estruturas.h"


symbol_table *create_symbol_table(char *title, int definition);
	
/*adicionar/criar um simbolo*/
void add_symbol(symbol_table *table, char *name, char *type, int param, param_type *pt);
/*fazer lista de parametros de entrada, retorna o primeiro da lista*/
param_type *add_entry_param(param_type *pt, char *param);

symbol_table *start_table(Node *start, symbol_table *table);
Node *add_str_pointer(char **strpointer, Node *node);

void declaration_arr_var(symbol_table *gtable, symbol_table *ltable, Node *no_actual);
/*cria tabela e adicionar uma linha à global*/
void func_declaration_sem(Node *node, symbol_table *global_table);
void func_definition_sem(Node *node, symbol_table *global_table);
void printparams(param_type *n);
void print_tables(symbol_table *tabela_inicial);
