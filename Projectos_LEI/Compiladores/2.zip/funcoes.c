/*Os_Accepted*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "estruturas.h"

Node *create_node(char *type_node, char* value){
	if(value == NULL){
		Node *tmp = (Node*)malloc(sizeof(Node));

		if(tmp == NULL) return NULL;
		
		tmp->child = NULL;
		tmp->brother = NULL;
		tmp->node_type = (char*)malloc(strlen(type_node)+1);
		
		strcpy(tmp->node_type, type_node);

		return tmp;
	}else{
		Node *tmp = (Node*)malloc(sizeof(Node));
		
		if(tmp == NULL) return NULL;
		
		tmp->child = NULL;
		tmp->brother = NULL;
		tmp->node_type = (char*)malloc(strlen(type_node)+strlen(value)+3);
		
		sprintf(tmp->node_type, "%s(%s)", type_node, value);

		return tmp;
	}
}

Node *add_child(Node* father_node, Node* child_node){
	if(child_node==NULL) return NULL;
	
	Node *tmp = father_node->child;
	
	if (tmp == NULL){
		father_node->child = child_node;
	}else{
		while(tmp->brother != NULL)
			tmp = tmp->brother;

		tmp->brother = child_node;
	}

	return father_node;
}

void add_first_child(Node *father_node, Node* first_child_node){
	if(first_child_node==NULL) return;

	Node *tmp_child;
	Node *tmp_father = father_node->brother;

	if(father_node->child == NULL){
		father_node->child = first_child_node;
	}else{
		tmp_child = father_node->child;
		father_node->child = first_child_node;
		first_child_node->brother = tmp_child;
	}

	while(tmp_father!= NULL){
		tmp_child = tmp_father->child;
		tmp_father->child = create_node(first_child_node->node_type, NULL);
		tmp_father->child->brother = tmp_child;
		tmp_father = tmp_father->brother;
	}
}

Node *add_brother(Node* brother_node, Node* new_brother){
	if(new_brother == NULL) return brother_node;
	if (brother_node == NULL) return new_brother;
	
	Node *tmp = brother_node;

	while(tmp->brother != NULL){
		tmp = tmp->brother;
	}

	tmp->brother = new_brother;
	return brother_node;
}

void print_tree(Node* node, int count){
	int i;
	while(node != NULL){
		for(i=0; i< count; i++){
			printf(".."); /*imprimir pontos*/
		}
		
		printf("%s\n", node->node_type);
		
		if(node->child != NULL){
			print_tree(node->child, count+1); /*se tiver filho, imprime*/
		}

		node = node->brother;
	}
	
	return;
}

void clean_tree(Node* node){
	Node *tmp;
	while(node != NULL){
		if(node->child != NULL){
			clean_tree(node->child);			
		}
		if(node->node_type != NULL)
			free(node->node_type);
		tmp = node->brother;
		free(node);
		node = tmp;
	}
	return;
}