/*Os_Accepted*/
#ifndef ESTR_H
#define ESTR_H

typedef struct Node Node;

struct Node{
	char *node_type;
	Node *child;
	Node *brother;
};

#endif
