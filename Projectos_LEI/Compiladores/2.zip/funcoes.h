/*Os_Accepted*/
#include "estruturas.h"

Node *create_node(char *type_node, char* value);
Node *add_child(Node* father_node, Node* child_node);
void add_first_child(Node *father_node, Node* first_child_node);
Node *add_brother(Node* brother_node, Node* new_brother);
void print_tree(Node* node, int count);
void clean_tree(Node* node);