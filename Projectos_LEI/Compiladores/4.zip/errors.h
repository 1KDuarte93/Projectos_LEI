/*Os_Accepted*/
#include "estruturas.h"

int check_lvalue(Node * node, symbol_table *tlocal, symbol_table *tglobal);
int check_conftypes(char *type1, char *type2, Node *node);
int check_call(Node *node);
void is_not_func(Node* no);
int is_defined(Node *node, symbol_table *gtable, symbol_table *ltable, char *type);
char *unknown_symbol(Node *no);
int check_void(char *type, Node *id);
int check_valid_operator_unarios(char *no_operador, char * type);
int check_params(Node *paramlist_node);
int invalid_use_void_decl(Node *id_func);