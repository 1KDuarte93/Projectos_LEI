#include <stdio.h>
#include <stdlib.h>
#include "estruturas.h"
#include "llvm.h"
#include <string.h>
/*percorrer arvore e ir gerando codigo*/
/*i32 - int, i8 - char*/

int count;
param_type *str_global;

void cod_inter(symbol_table *global){
	symbol_element *tmp_element;
	param_type* parametro;
	int asts, i;

	count = 1;
	tmp_element = global->symbol->next->next->next; /*atoi, itoa, puts*/

	while(tmp_element != NULL){ /*VAR GLOBAL*/
		if(tmp_element->paramtype == NULL){ /*NOT FUNC*/
			printf("@%s = common global", tmp_element->name);
			print_var_type(tmp_element->type, 0);
			printf("\n");
		}
		tmp_element = tmp_element->next;
	}
	/* FUNÇÕES PRÉ-DEFINIDAS */
	/* atoi (declaração apenas) */
	printf("\ndeclare i32 @atoi(i8*)\n\n");
	printf("@.str = private unnamed_addr constant [3 x i8] c\"%%d\\00\"\n");

	/* itoa (definição) */
	printf("define i8* @itoa(i32 %%n, i8* %%buf){\n\t%%1 = alloca i32\n\t%%2 = alloca i8*\n\tstore i32 %%n, i32* %%1\n\tstore i8* %%buf, i8** %%2\n\t%%3 = load i8** %%2\n\t%%4 = load i32* %%1\n\t%%5 = call i32 (i8*, i8*, ...)* @sprintf(i8* %%3, i8* getelementptr inbounds ([3 x i8]* @.str, i32 0, i32 0), i32 %%4)\n\t%%6 = load i8** %%2\n\tret i8* %%6\n}\n\n");
	printf("declare i32 @sprintf(i8*, i8*, ...)\n");
	/* puts (declaração apenas) */
	printf("declare i32 @puts(i8*)\n");

	printf("declare i32 @printf(i8*, ...)\n");
	/*REPOR - PRIMEIRO*/
	tmp_element = global->symbol->next->next->next; /*atoi, itoa, puts*/

	while(tmp_element != NULL){ /*FUNCOES*/
		if (tmp_element->paramtype != NULL && search_title(tmp_element->name, global)){
			/* conta asteriscos */
			asts = conta_asteriscos(tmp_element->type);

			/* tipo da funcao */
			if(tmp_element->type[0] == 'i') /* int */
				printf("\ndeclare i32");
			else /* char ou void */
				printf("\ndeclare i8");

			for(i = 0; i < asts; i++)
				printf("*");

			/* nome da funcao */
			printf(" @%s(",tmp_element->name);

			/* parametros da funcao */
			parametro = tmp_element->paramtype;

			while(parametro != NULL){
				if(parametro->type_name[0] == 'i') /* int */
					printf("i32");
				else /* char ou void */
					printf("i8");
				asts = conta_asteriscos(parametro->type_name);
				for(i = 0; i < asts; i++)
					printf("*");
				
				if(parametro->next != NULL)
					printf(", ");
				else
						printf(")\n");
				parametro = parametro->next;
			}
		}
		tmp_element = tmp_element->next;
	}
	/*tabela global acabou*/
	printf("\n");
	func_llvm(global->next, global);
}

void func_llvm(symbol_table *local, symbol_table *global){ /**/
	/*1o element - return type*/
	Node *tmp_node;
	symbol_element *tmp_element;
	int asts, i, j;
	while(local != NULL){ /*percorrer tabelas de funcoes*/
		tmp_element = local->symbol;
		if(tmp_element != NULL){
			printf("\ndefine");
			asts = 0;
			if(tmp_element->type[0] == 'i' && tmp_element->type[1]=='n' && tmp_element->type[2]=='t'){
				printf(" i32");
				i = 3;
			}
			else if((tmp_element->type[0] == 'c' && tmp_element->type[1]=='h' && tmp_element->type[2]=='a' && tmp_element->type[3]=='r') ||
						(tmp_element->type[0] == 'v' && tmp_element->type[1]=='o' && tmp_element->type[2]=='i' && tmp_element->type[3]=='d')){
				printf(" i8");
				i = 4;
			}
			while(tmp_element->type[i] == '*'){
				asts++;
				i++;
			}
			for(j=0; j<asts; j++)
				printf("*");
			printf(" @%s", local->title);
			if(tmp_element->next != NULL && tmp_element->next->param == 1)
				print_params(tmp_element->next); /*envia primeiro parametro*/
			else
				printf("()");
			printf("{\n");
			tmp_element = alloca_store_params(tmp_element->next);/*alloca para os parametros e faz o store*/
			printf("ret i32 0}\n");
		}
		tmp_element = declvar_local(tmp_element);
		/*funcbody*/
		if(local->funcBody != NULL){
			tmp_node = local->funcBody->child;
			/*encontrar no depois das declaracoes*/
			while(tmp_node!=NULL && (strcmp(tmp_node->node_type, "Declaration")==0 || strcmp(tmp_node->node_type, "ArrayDeclaration")==0)){
				tmp_node = tmp_node->brother;
			}
			funcBody_llvm(tmp_node, local, global);
		}
		local = local->next;
	}
}

symbol_element *print_params(symbol_element* tmp_element){
	int i = 0;
	if(tmp_element != NULL && tmp_element->param == 1){
		if(tmp_element->type[0] == 'i' && tmp_element->type[1]=='n' && tmp_element->type[2]=='t'){
			printf("(i32");
			i=3;
		}
		else if((tmp_element->type[0] == 'c' && tmp_element->type[1]=='h' && tmp_element->type[2]=='a' && tmp_element->type[3]=='r') ||
					(tmp_element->type[0] == 'v' && tmp_element->type[1]=='o' && tmp_element->type[2]=='i' && tmp_element->type[3]=='d')){
			printf("(i8");
			i=4;
		}
		while(tmp_element->type[i] == '*'){
			printf("*");
			i++;
		}
		printf(" %%%s", tmp_element->name);
		tmp_element = tmp_element->next;
	}
	

	while(tmp_element != NULL && tmp_element->param == 1){
		if(tmp_element->type[0] == 'i' && tmp_element->type[1]=='n' && tmp_element->type[2]=='t'){
			printf(", i32");
			i=3;
		}
		else if((tmp_element->type[0] == 'c' && tmp_element->type[1]=='h' && tmp_element->type[2]=='a' && tmp_element->type[3]=='r') ||
					(tmp_element->type[0] == 'v' && tmp_element->type[1]=='o' && tmp_element->type[2]=='i' && tmp_element->type[3]=='d')){
			printf(", i8");
			i=4;
		}
		while(tmp_element->type[i] == '*'){
			printf("*");
			i++;
		}
		printf(" %%%s", tmp_element->name);
		tmp_element = tmp_element->next;
	}
	printf(")");
	return tmp_element;
}

symbol_element *declvar_local(symbol_element *tmp_element){
	if(tmp_element != NULL)
	while(tmp_element != NULL){
		printf("\t%%%s = alloca", tmp_element->name);
		print_var_type(tmp_element->type, 1);
		printf("\n");

		tmp_element = tmp_element->next;
	}
	return tmp_element;
}

symbol_element *alloca_store_params(symbol_element *tmp_element){
	int nasts, i;
	while(tmp_element != NULL && tmp_element->param == 1){
		nasts = 0;
		printf("\t%%%d = alloca", count);
		sprintf(tmp_element->var_number, "%d", count);
		print_var_type(tmp_element->type, 1); /*store i32 %c, i32* %1,*/
		printf("\n");
		/*store*/
		printf("\tstore");
		print_var_type(tmp_element->type, 1);
		for(i=0; i<nasts; i++)
				printf("*");
		printf(" %%%s, ", tmp_element->name);
		print_var_type(tmp_element->type, 1);
		printf("*");
		for(i=0; i<nasts; i++)
				printf("*");
		printf(" %%%d\n", count);

		count++;
		tmp_element = tmp_element->next;
	}
	return tmp_element;
}

int conta_asteriscos(char* nome){
	int i = 0;
	char* ponteiro = nome;

	while(*ponteiro != '\0'){
		if(*ponteiro == '*'){
			i++;
		}
		ponteiro++;
	}
	return i;
}

int search_title(char *title, symbol_table *table){
	symbol_table *tmp;
	tmp = table;
	while(tmp != NULL){
		if(strcmp(tmp->title, title)==0){
			if(tmp->definition > 0)
				return 0;
			else
				return 1;
		}
		tmp = tmp->next;
	}
	return 1;
}

void print_var_type(char *type, int flag){ /*0 - global, 1 - local*/
	int asts;
	int i;
	char tipo[4];

	if(type[0] == 'i'){
		strcpy(tipo, "i32");
		i = 3;
	}
	else{
		strcpy(tipo, "i8");
		i = 4;
	}
	asts = conta_asteriscos(type);
	i = i + asts;

	if(type[i]== '['){ /*ARRAY*/
		i++;
		printf(" [");
		while(type[i] != ']'){ /*imprime tamanho*/
			printf("%c", type[i]);
			i++;
		}
		printf(" x %s", tipo);
		for (i=0; i<asts; i++)
			printf("*");
		printf("]");
		if(flag == 0) /*GLOBAL*/
			printf(" zeroinitializer");
	}
	else{ /*VAR*/
		printf(" %s", tipo);
		for (i=0; i<asts; i++)
			printf("*");
		if(flag == 0){ /*GLOBAL*/
			if(asts == 0)
				printf(" 0");
			else
				printf(" null");
		}
	}
}

char *funcBody_llvm(Node *funcBodyNode, symbol_table *local, symbol_table *global){
	if (funcBodyNode == NULL)
		return NULL;
	else if(funcBodyNode->node_type[0] =='I' && funcBodyNode->node_type[1] =='d'){ /*é um ID*/
		/*verificar se é var local, global, ou recebida por parametro*/
		return search_var_by_name(funcBodyNode->type, local, global);
	}
	else if(strcmp(funcBodyNode->node_type, "Call")==0){
		return call_functions(funcBodyNode, local, global);
	}
	return NULL;
}


char *search_var_by_name(char *var, symbol_table *local, symbol_table *global){
	/*primeiro procura local*/
	char *return_var;
	return_var = (char*)malloc(50);
	symbol_element *tmp_element;
	tmp_element = local->symbol->next; /*salta o tipo de retorno*/
	while(tmp_element != NULL){
		if(strcmp(var, tmp_element->name)==0){
			if(tmp_element->param == 1){ /*se é parametro retorna %x*/
				strcpy(return_var, tmp_element->var_number);
			}
			else{
				strcpy(return_var, "%");
				strcat(return_var, tmp_element->name);
			}
			return return_var;
		}
		tmp_element = tmp_element->next;
	}
	tmp_element = global->symbol->next->next->next; /*atoi, itoa, puts*/
	while(tmp_element != NULL){
		if(strcmp(var, tmp_element->name)==0){
			strcpy(return_var, "@");
			strcat(return_var, tmp_element->name);
			return return_var;
		}
		tmp_element = tmp_element->next;
	}
	strcpy(return_var, "ERRRO!!!!!!\n");
	return return_var;
}

char *call_functions(Node *node, symbol_table *local, symbol_table *global){
	Node *tmp_node;
	int tam, count2;
	char string[50];
	tmp_node = node->child;
		if(strcmp(tmp_node->value, "printf")==0){
			/*@str*/
			while(str_global != NULL)
			str_global = (param_type*)malloc(sizeof(param_type));
			str_global->next = NULL;
			str_global->type_name = (char*)malloc(100);

			strcpy(string, tmp_node->child->value);
			count2 = count;
			loads(tmp_node->brother->brother, local, global);
			printf("\n\t%%%d = call i32 (i8*, ...)* @printf(i8* getelementptr inbounds (", count);
			/*1o string*/
			tmp_node = tmp_node->brother;
			tam = strlen(tmp_node->value);
			printf("[%d x i8] *", tam);
			count++;
			/*nome_var_string*/

			printf("@.str%d, i32 0, i32 0)", count);

			sprintf(str_global->type_name, "@str%d = private unnamed_addr constant [%d x i8] c%s\n", count, tam, string);

			tmp_node = tmp_node->brother;
			while(tmp_node){
				printf(", %s %%%d", get_var_type(tmp_node->type), count2);
				count2++;
				tmp_node = tmp_node->brother;
			}
			printf(")\n");

	}
	if(node->brother != NULL)
		funcBody_llvm(node->brother, local, global);
	return NULL;
}

void loads(Node *node, symbol_table *local, symbol_table *global){ /*node = call->child->brother*/
	Node *tmp_node;
	tmp_node = node;

	while(tmp_node != NULL){
		printf("\n\t%%%d = load %s* %s", count, get_var_type(tmp_node->type), search_var_by_name(tmp_node->value, local, global));
		count++;
		tmp_node = tmp_node->brother;
	}
}


char *get_var_type(char *type){ /*0 - global, 1 - local*/
	int asts;
	int i;
	char tipo[4];
	char *return_type;
	return_type = (char*)malloc(100);
	if(type[0] == 'i'){
		strcpy(tipo, "i32");
		i = 3;
	}
	else{
		strcpy(tipo, "i8");
		i = 4;
	}
	asts = conta_asteriscos(type);
	i = i + asts;

	if(type[i]== '['){ /*ARRAY*/
		i++;
		strcpy(return_type, "[");
		while(type[i] != ']'){ /*imprime tamanho*/
			sprintf(return_type, "%s%c", return_type, type[i]);
			i++;
		}
		strcat(return_type, " x ");
		strcat(return_type, tipo);
		for (i=0; i<asts; i++)
			strcat(return_type, "*");
		strcat(return_type, "]");
	}
	else{ /*VAR*/
		strcat(return_type, tipo);
		for (i=0; i<asts; i++)
			strcat(return_type, "*");
	}
	return return_type;
}