#include "estruturas.h"

void cod_inter(symbol_table *global);
void func_llvm(symbol_table *local, symbol_table *global);
symbol_element *print_params(symbol_element* tmp_element);
symbol_element *declvar_local(symbol_element *tmp_element);
symbol_element * alloca_store_params(symbol_element *tmp_element);
int conta_asteriscos(char* nome);
int search_title(char *title, symbol_table *table);
void print_var_type(char *type, int flag);
char *funcBody_llvm(Node *funcBodyNode, symbol_table *local, symbol_table *global);
char *search_var_by_name(char *var, symbol_table *local, symbol_table *global);
char *call_functions(Node *node, symbol_table *local, symbol_table *global);
void loads(Node *node, symbol_table *local, symbol_table *global);
char *get_var_type(char *type);