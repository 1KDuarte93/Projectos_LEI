/*Os_Accepted*/
#include "tabela_simbolos.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "estruturas.h"
#include "errors.h"
#include "mod_tree.h"
#include <ctype.h>

symbol_table *create_symbol_table(char *title, int definition){
	symbol_table *tmp;
	tmp = (symbol_table*)malloc(sizeof(symbol_table));
	tmp->title = (char*)malloc(strlen(title)+1);
	strcpy(tmp->title, title);
	tmp->symbol = NULL;
	tmp->next = NULL;
	tmp->definition = definition;
	tmp->funcBody = NULL;
	return tmp;
}
	
/*adicionar/criar um simbolo*/
void add_symbol(symbol_table *table, char *name, char *type, int param, param_type *pt){
	symbol_element *tmp_element;
	symbol_element *tmp_list_elements;

	tmp_element = (symbol_element*)malloc(sizeof(symbol_element));
	if(name != NULL)
		{tmp_element->name = (char*)malloc(strlen(name)+1);
		strcpy(tmp_element->name, name);}
	else{tmp_element->name = (char*)malloc(5);
		strcpy(tmp_element->name, "Null");
	}
	if(type != NULL){
		tmp_element->type = (char*)malloc(strlen(type)+1);
		strcpy(tmp_element->type, type);
		tmp_element->type[0] = tolower(tmp_element->type[0]);
	}else{
		tmp_element->type = (char*)malloc(5);
		strcpy(tmp_element->type, "Null");
	}
	
	tmp_element->param = param;
	tmp_element->paramtype = pt;
	tmp_element->next = NULL;
	tmp_list_elements = table->symbol;

	if(tmp_list_elements == NULL){table->symbol = tmp_element; return;}

	while(tmp_list_elements->next!=NULL){
		tmp_list_elements = tmp_list_elements->next;
	}
	tmp_list_elements->next = tmp_element;
	return;
}

/*fazer lista de parametros de entrada, retorna o primeiro da lista*/
param_type *add_entry_param(param_type *pt, char *param){
	param_type *tmp;
	if(pt == NULL){
		tmp = (param_type*)malloc(sizeof(param_type));
		tmp->type_name=(char*)malloc(strlen(param)+1);
		strcpy(tmp->type_name, param);
		tmp->next = NULL;
		return tmp;
	}
	else{
		tmp = pt;
		while(tmp->next != NULL){
			tmp = tmp->next;
		}
		tmp->next = (param_type*)malloc(sizeof(param_type));
		tmp->next->type_name=(char*)malloc(strlen(param)+1);
		strcpy(tmp->next->type_name, param);
		tmp->next->next = NULL;
		return pt;
	}
}

symbol_table *start_table(Node *start, symbol_table *gtable){
	/*function Definition, function declaration, declaration*/
	Node *tmp;
	param_type *pttmp;
	/*criar tabela com campos default*/
	gtable = create_symbol_table("Global Symbol Table", 1);
	
	/*add atoi int(char*)*/
	pttmp = add_entry_param(NULL, "char*");
	add_symbol(gtable, "atoi", "int", 0, pttmp);
	gtable->next = create_symbol_table("atoi", 0);

	/*add itoa char*(int,char*)*/
	gtable->next->next = create_symbol_table("itoa", 0);
	pttmp = NULL;
	pttmp=add_entry_param(NULL, "int");
	pttmp=add_entry_param(pttmp, "char*");
	add_symbol(gtable, "itoa", "char*", 0, pttmp);
	
	/*add puts int(char*)*/
	gtable->next->next->next = create_symbol_table("puts", 0);
	pttmp = NULL;
	pttmp=add_entry_param(NULL, "char*");
	add_symbol(gtable, "puts", "int", 0, pttmp);

	tmp = start->child;
	if(tmp==NULL){return NULL;}
	while(tmp!= NULL){
		if(strcmp(tmp->node_type,"FuncDefinition")==0){func_definition_sem(tmp, gtable);}
		else if(strcmp(tmp->node_type,"FuncDeclaration")==0){func_declaration_sem(tmp, gtable);}
		else if(strcmp(tmp->node_type, "ArrayDeclaration") == 0 || strcmp(tmp->node_type, "Declaration") == 0){declaration_arr_var(gtable, NULL, tmp);}
		tmp = tmp->brother;
	}
	return gtable;
}

Node *add_str_pointer(char **strpointer, Node *node){ /*pointers*/
	int pcount = 0,i;
	Node *type = node; /* tipo */
	node = node->brother;
	while(node != NULL && strcmp(node->node_type, "Pointer")==0){
		pcount++;
		node = node->brother;} /*conta * */

	*strpointer = (char*)malloc(strlen(type->node_type)+pcount+1);
	strcpy(*strpointer, type->node_type);
	*strpointer[0]=tolower(*strpointer[0]);
	for(i=0; i<pcount; i++)
		strcat(*strpointer, "*");
	/*if(flag_check_void != 1)
		if(check_void(*strpointer, node)){
			*strpointer = (char*)malloc(6);
			strcpy(*strpointer, "undef");
			return node;
		}*/
	return node; /*retorna o node do id ou null*/
}


void declaration_arr_var(symbol_table *gtable, symbol_table *ltable, Node *no_actual){
	char *type, *ident, *type2=NULL;
	int var_len;
	Node *tmp_child, *tmp_id;
	tmp_child = no_actual->child; /*tipo*/

	tmp_child = add_str_pointer(&type, tmp_child); /*retorna no depois do ultimo pointer - ID*/
	if(check_void(type, tmp_child)){
		if(ltable == NULL){
			add_symbol(gtable, tmp_child->value, "undef", 0, NULL);
			return;
		}
		else{
			add_symbol(ltable, tmp_child->value, "undef", 0, NULL);
			return;
		}
	}
	ident = tmp_child->value;
	
	tmp_id = tmp_child;
	tmp_child = tmp_child->brother; /*NULL ou POINTER*/

	if(tmp_child != NULL && ltable == NULL){ /*ARRAY*/ /*GLOBAL TABLE*/
		type2 = (char*)malloc(strlen(type)+strlen(tmp_child->value)+3);
		if(tmp_child->value[0] == '0'){
			sscanf(tmp_child->value, "%o", &var_len); /*conversao para decimal*/
			sprintf(type2, "%s[%d]", type, var_len);
			if(is_defined(tmp_id, gtable, ltable, type2) != 0){
				return;
			}
		}else{
			sprintf(type2, "%s[%s]", type, tmp_child->value);
			if(is_defined(tmp_id, gtable, ltable, type2) != 0){
				return;
			}
		}
		add_symbol(gtable, ident, type2, 0, NULL);
	}
	else if(tmp_child != NULL && ltable != NULL){ /*ARRAY*/ /*LOCAL TABLE*/
		type2 = (char*)malloc(strlen(type)+strlen(tmp_child->value)+3);
		if(tmp_child->value[0] == '0'){
			sscanf(tmp_child->value, "%o", &var_len);
			sprintf(type2, "%s[%d]", type, var_len);
			if(is_defined(tmp_id, gtable, ltable, type2) != 0){
				return;
			}
		}else{
			sprintf(type2, "%s[%s]", type, tmp_child->value);
			if(is_defined(tmp_id, gtable, ltable, type2) != 0){
				return;
			}
		}
		add_symbol(ltable, ident, type2, 0, NULL);
	}
	else if (ltable == NULL){ /*VAR LOCAL TABLE*/
		if(is_defined(tmp_id, gtable, ltable, type) != 0){
			return;
		}
		add_symbol(gtable, ident, type, 0, NULL);
	}
	else if (ltable != NULL){ /*ARR GLOBAL TABLE*/
		if(is_defined(tmp_id, gtable, ltable, type) != 0){
			return;
		}
		add_symbol(ltable, ident, type, 0, NULL);
	}
}


/*cria tabela e adicionar uma linha à global*/
void func_declaration_sem(Node *node, symbol_table *global_table){
	symbol_table *tmp_st, *tabela_aux;
	symbol_element *anothertmp;
	Node *tmp_node, *func_name;
	char *strpointer, *return_type;
	param_type *paramlist=NULL;

	/*obter o nome da funcao*/
	tmp_node = node->child;
	func_name = add_str_pointer(&return_type, tmp_node);

	
	anothertmp = global_table->symbol;
	if(invalid_use_void_decl(func_name))
		return;

	if(check_params(func_name->brother)){
		return;
	}
	/*verifica se já foi declarada*/
	while(anothertmp != NULL){ /*Se já foi declarada antes, verifica parametros*/
		if(strcmp(func_name->value, anothertmp->name)==0){
			//check_params(func_name, anothertmp->paramtype);
			return;
		}
		anothertmp = anothertmp->next;
	}



	tmp_st = create_symbol_table(func_name->value, 0); /*0 - cria tabela nao impressa*/
	/*ligar tabela*/
	tabela_aux = global_table;
	while(tabela_aux->next !=NULL)
		tabela_aux = tabela_aux->next;

	tabela_aux->next = tmp_st;
	/*ler parametros da funcao*/
	tmp_node = tmp_node->brother;
	while(tmp_node != NULL && strcmp(tmp_node->node_type, "ParamList") != 0){
		tmp_node = tmp_node->brother;
	}

	if(tmp_node == NULL){
		return;
	}
	tmp_node = tmp_node->child; /*primeiro paramDeclaration*/

	while(tmp_node != NULL){
		strpointer = NULL;
		add_str_pointer(&strpointer, tmp_node->child);
		
		if(strpointer != NULL){
			paramlist = add_entry_param(paramlist, strpointer);
		}
		
		tmp_node = tmp_node->brother;
	}
	add_symbol(global_table, func_name->value, return_type, 0, paramlist);
}

void func_definition_sem(Node *node, symbol_table *global_table){
	symbol_table *tmp_st = NULL, *tabela_aux, *tmp_st1 = NULL;
	symbol_element *anothertmp;
	Node *tmp_node, *id_node, *func_name;
	char *strpointer, *return_type;
	param_type *paramlist=NULL;

	tmp_node = node->child; /*tipo da funcao*/
	/* terceiro parametro - flag para a funcao CHECK_VOID */
	func_name = add_str_pointer(&return_type, tmp_node);
	
	anothertmp = global_table->symbol;
	if(invalid_use_void_decl(func_name))
		return;
	if(check_params(func_name->brother)){
		return;
	}
	/*verifica se já foi declarada*/
	while(anothertmp != NULL){ /*Se já foi declarada antes, verifica parametros*/
		if(strcmp(func_name->value, anothertmp->name)==0){
			//if(check_params(func_name, anothertmp->paramtype))
				//return;
			break;
		}
		anothertmp = anothertmp->next;
	}

	
	/*Se nao foi declarada*/
	if(anothertmp == NULL){
		tmp_st1 = create_symbol_table(func_name->value, 1);
		add_symbol(tmp_st1, "return", return_type, 0, NULL);
		tabela_aux = global_table;
		while(tabela_aux->next !=NULL)
			tabela_aux = tabela_aux->next;
		tabela_aux->next = tmp_st1;
		tmp_st = tabela_aux->next;
	}
	else{ /*Se ja foi declarada*/
		tabela_aux = global_table;
		while(tabela_aux != NULL){
			if(strcmp(tabela_aux->title, func_name->value) == 0){
				tabela_aux->definition = 1;
				add_symbol(tabela_aux, "return", return_type, 0, NULL);
				tmp_st = tabela_aux;
				break;
			}
			tabela_aux = tabela_aux->next;
		}
		if(tabela_aux==NULL) return;
	}

	/*ler parametros da funcao*/
	tmp_node = node->child;
	while(tmp_node != NULL && strcmp(tmp_node->node_type, "ParamList") != 0){
		tmp_node = tmp_node->brother;
	}
	if(tmp_node == NULL) return;

	tmp_node = tmp_node->child; /*primeiro paramDeclaration*/

	while(tmp_node != NULL){
		strpointer = NULL;
		id_node = add_str_pointer(&strpointer, tmp_node->child);
		/*Adiciona a local*/
		if(id_node!= NULL){
			add_symbol(tmp_st, id_node->value, strpointer, 1, NULL);
			paramlist = add_entry_param(paramlist, strpointer);
		}else{
			paramlist = add_entry_param(paramlist, strpointer);
		}
		
		tmp_node = tmp_node->brother;
	}
	tmp_node = NULL;


	if(anothertmp == NULL) /*Se nao foi ainda declarada, adiciona entrada na GLOBAL*/
		add_symbol(global_table, func_name->value, return_type, 0, paramlist);

	/*variaveis locais - funcbody*/
	tmp_node = node->child;
	while(tmp_node != NULL && strcmp(tmp_node->node_type, "FuncBody") != 0)
		tmp_node = tmp_node->brother;
	if(tmp_node == NULL) return;

	tmp_st->funcBody = tmp_node; /*META 4*/

	/*encontrou funcbody*/
	tmp_node = tmp_node->child;
	while(tmp_node != NULL && (strcmp(tmp_node->node_type, "Declaration")== 0 || strcmp(tmp_node->node_type, "ArrayDeclaration")== 0)){
		declaration_arr_var(global_table, tmp_st, tmp_node);
		tmp_node = tmp_node->brother;
	}
	if(tmp_node != NULL){
		find_expr(tmp_st, global_table, tmp_node);
	}
}


void print_tables(symbol_table *tabela_inicial){
    symbol_table *tmp_table = tabela_inicial;
    symbol_element *tmp_symbol;
    param_type *pttmp;
    /*tabela global*/
    printf("===== %s =====\n", tabela_inicial->title);
    tmp_symbol = tabela_inicial->symbol;
    while(tmp_symbol != NULL){
    	if(tmp_symbol->paramtype == NULL)
        	printf("%s\t%s\n",tmp_symbol->name, tmp_symbol->type);
        else{
        	printf("%s\t%s(",tmp_symbol->name, tmp_symbol->type);
        	pttmp = tmp_symbol->paramtype;
        	printf("%s", pttmp->type_name);
        	pttmp = pttmp->next;
        	while(pttmp != NULL){
        		printf(",%s", pttmp->type_name);
        		pttmp=pttmp->next;
        	}
        	printf(")\n");
        }
        tmp_symbol=tmp_symbol->next;
    }

    /*Restantes tabelas*/
 	tmp_symbol = NULL;
 	tmp_table = tmp_table->next;
    while(tmp_table != NULL){
    	if(tmp_table->definition == 1){
	        printf("\n===== Function %s Symbol Table =====\n",tmp_table->title);
	        tmp_symbol = tmp_table->symbol;
	        while(tmp_symbol != NULL){
	        	if(tmp_symbol->param==0)
	            	printf("%s\t%s\n",tmp_symbol->name, tmp_symbol->type);
	            else
	            	printf("%s\t%s\tparam\n",tmp_symbol->name, tmp_symbol->type);
	            tmp_symbol = tmp_symbol->next;
	        }
        }
    	tmp_table = tmp_table->next;
    }
    printf("\n");
}


