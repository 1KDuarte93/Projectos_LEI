/*Os_Accepted*/
#include "estruturas.h"
#include "mod_tree.h"
#include "errors.h"
#include "tabela_simbolos.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

void find_expr(symbol_table *tlocal, symbol_table *tglobal, Node *node){
	Node *notmp;
	notmp = node;
	while(notmp!= NULL){
		if(notmp->op_term != 0)
			add_type(tlocal, tglobal, notmp);
		else if(notmp->child != NULL)
			find_expr(tlocal, tglobal, notmp->child);
		notmp = notmp->brother;
	}
}

char *add_type(symbol_table *tlocal, symbol_table *tglobal, Node *node){ /*recebeu uma expr*/
	/*1-normal expr. 2-unarios, 3-id, 4-IntLit, ChrLit, StrLit*/
	char *tmp=NULL, *tmp1, *tmp2;
	if(node->op_term==1){
		tmp1 = add_type(tlocal, tglobal, node->child);
		tmp2 = add_type(tlocal, tglobal, node->child->brother);
		tmp1 = cmp_type(tmp1, tmp2, node->node_type);
		return cat_type(node, tmp1);
	}
	if(node->op_term == 2){
		/*check_valid_operator_unarios(node->node_type,tmp);*/ /*Depois descomenta-se*/
		return unary_op(tglobal, tlocal, node);
	}
	else if(node->op_term == 3){

		tmp = search_idtype(tglobal, tlocal, node);
		/*if(tmp==NULL)
			return (unknown_symbol(node));*/ /*DESCOMENTAR*/
		return cat_type(node, tmp);
	}
	else if(node->op_term == 4){ /*IntLit, ChrLit, StrLit*/
		return cat_type(node, search_vartype(node));
	}
	else if(node->op_term == 5){ /*Deref*/
		return deref_type(tlocal, tglobal, node);
	}
	else if(node->op_term == 6){ /*Call*/
		return calls_type(tlocal, tglobal, node);
	}
	else if(node->op_term == 7){ /*addr*/
		return addr_type(tlocal, tglobal, node);
	}
	else if(node->op_term == 8){ /*LT, GT, etc*/
		return comp_op(tlocal, tglobal, node);
	}
	return NULL;
}



char *calls_type(symbol_table *tlocal, symbol_table *tglobal, Node *node){ /*1o filho - nome da funcao*/
	Node *tmp;
	char *idtype, *return_var;
	symbol_element *symbol_list;
	tmp = node->child->brother;
	while(tmp!=NULL){
		add_type(tlocal, tglobal, tmp);
		tmp = tmp->brother;
	}


	if(search_ltable(tglobal, node->child->value) == NULL){ /*procura pelos titulos das tabelas*/
		/*procura var em local*/
		symbol_list = tlocal->symbol;
		if(tlocal != NULL){
			while(symbol_list != NULL) {
				if(strcmp(symbol_list->name, node->child->value)==0){ /*verifica se existe ver com esse nome*/
					printf("Line %d, col %d: Symbol %s is not a function\n", node->child->linha, node->child->coluna, node->child->value);
					cat_type(node, "undef");
					return node->type;
				}
				symbol_list = symbol_list->next;
			}
		}
		if (tglobal != NULL){
			symbol_list = tglobal->symbol;
			while(symbol_list != NULL) {
				if(strcmp(symbol_list->name, node->child->value)==0){ /*verifica se existe ver com esse nome*/
					printf("Line %d, col %d: Symbol %s is not a function\n", node->child->linha, node->child->coluna, node->child->value);
					cat_type(node, "undef");
					return node->type;
				}
				symbol_list = symbol_list->next;
			}
		}
		printf("Line %d, col %d: Unknown symbol %s\n", node->child->linha, node->child->coluna, node->child->value);
		cat_type(node, "undef");
		return node->type;
	}
	idtype = search_idtype(tglobal, tlocal, node->child);
	cat_type(node->child, idtype);
	return_var = cat_type(node, idtype);
	/*check_call(node);						verificar*/
	return return_var;

}

char *deref_type(symbol_table *tlocal, symbol_table *tglobal, Node *node){
	char *tmp1, *tmp2;
	tmp1 = add_type(tlocal, tglobal, node->child); /*unico filho do deref*/
	/*verificar se tem asts*/
	if(tmp1[strlen(tmp1)-1] == '*'){
		tmp2 = (char*)malloc(strlen(tmp1));
		memcpy(tmp2, tmp1, strlen(tmp1)-1);
		cat_type(node, tmp2);
		return tmp2;
	}
	cat_type(node, tmp1);
	return tmp1;
}

char *addr_type(symbol_table *tlocal, symbol_table *tglobal, Node *node){
	char *tmp1, *tmp2;
	tmp1 = add_type(tlocal, tglobal, node->child); /*unico filho do addr*/
	tmp2 = (char*)malloc(strlen(tmp1)+2);
	strcpy(tmp2, tmp1);
	strcat(tmp2, "*");
	cat_type(node, tmp2);
	return tmp2;
}


char *search_vartype(Node *no){
	int i, tamanho_strlit=0;
	char tmp[6];
	char *return_var = NULL;
	for(i=0; i<6; i++){
		tmp[i] = no->node_type[i];
	}
	if(strcmp(tmp, "IntLit")==0){
		return_var = (char*)malloc(4);
		strcpy(return_var, "int");
	}
	else if (strcmp(tmp, "ChrLit")==0){
		return_var = (char*)malloc(5);
		strcpy(return_var, "int");
	}
	else if (strcmp(tmp, "StrLit")==0){
		return_var = (char*)malloc(20);
		tamanho_strlit = calcula_tamanho_strlit(no->value);
		sprintf(return_var, "char[%d]", tamanho_strlit);
	}
	else
		return NULL;
	return return_var;
}


char *search_idtype(symbol_table *gtable, symbol_table *ltable, Node *node){
	symbol_element *tmp;
	char *tmpstr;
	/*search local table*/
	tmp = ltable->symbol;
	while(tmp != NULL && strcmp(tmp->name, node->value) != 0){
		tmp = tmp->next;
	}
	if(tmp != NULL)/*var local*/{
	node->symbol_declaration = tmp;
		if(find_lsq(tmp->type) != 0){
			tmpstr = (char*)malloc(strlen(tmp->type)+1);
			strcpy(tmpstr,tmp->type);
			tmpstr[find_lsq(tmp->type)] = '*';
			tmpstr[find_lsq(tmp->type)+1] = '\0';
			return tmpstr;
		}
		return tmp->type;
	}
	tmp = gtable->symbol;
	while(tmp != NULL && strcmp(tmp->name, node->value) != 0){
		tmp = tmp->next;
	}
	if(tmp != NULL)/*var global*/{
		node->symbol_declaration = tmp;
		if(find_lsq(tmp->type) != 0){
			tmpstr = (char*)malloc(strlen(tmp->type)+1);
			strcpy(tmpstr,tmp->type);
			tmpstr[find_lsq(tmp->type)] = '*';
			tmpstr[find_lsq(tmp->type)+1] = '\0';
			return tmpstr;
		}
		return tmp->type;

	}
	return NULL;
}


symbol_table *search_ltable(symbol_table *gtable, char *name){
	symbol_table *tmp = gtable;
	while(tmp != NULL && strcmp(tmp->title, name) != 0){
		tmp = tmp->next;
	}
	return tmp;
}


char* cat_type(Node *no, char *tipo){
	no->type = (char*)malloc(strlen(tipo)+1);
	strcpy(no->type, tipo);
	return tipo;
}

char *delete_ast(char *str){
	int i = strlen(str)-1;
	while(str[i]=='*'){
		str[i] = '\0';
		i--;
	}
	return str;

}

int count_child_deref(Node *no){
	Node *tmp;
	int i=0;

	tmp = no;
	while(tmp != NULL && strcmp(tmp->node_type, "Deref")==0){
		tmp = tmp->child;
		i++;
	}
	return i;
}

int find_lsq(char *tipo){
	int i=0;
	while(tipo[i] != '\0'){
		if(tipo[i] == '['){
			return i;
		}
		i++;
	}
	return 0;
}


char *cmp_type(char *type1, char *type2, char *op){
	char *return_var;
	if(strcmp(op, "Store")==0)
		return type1;
	else if (strcmp(op, "Comma")==0)
		return type2;
	else if((strcmp(op, "Add")==0) || (strcmp(op, "Sub")==0) || (strcmp(op, "Mul")==0) || (strcmp(op, "Div")==0) || (strcmp(op, "Mod")==0)){
		if((strcmp(type1, "int")==0 && strcmp(type2, "int")==0) || (strcmp(type1, "char")==0 && strcmp(type2, "int")==0) || (strcmp(type1, "int")==0 && strcmp(type2, "char")==0) || (strcmp(type1, "char")==0 && strcmp(type2, "char")==0)){
			return_var = (char*)malloc(4);
			strcpy(return_var, "int");
			return return_var;
		}
		else if(strcmp(type1, type2)==0){
			return_var = (char*)malloc(4);
			strcpy(return_var, "int");
			return return_var;
		}
		else{
			return pointer_count(type1, type2);
		}
	}
		return pointer_count(type1, type2);
}

char *pointer_count(char *str1, char *str2){
	int i=strlen(str1)-1, j=strlen(str2)-1;
	int count1=0, count2=0;
	while(str1[i] == '*'){
		i--;
		count1 ++;
	}
	while(str2[j] == '*'){
		j--;
		count2++;
	}
	if(count1 > count2)
		return str1;
	else if(count1 < count2)
		return str2;

	/*entre char e int, return int*/
	if(str1[0] == 'i')
		return str1;
	return str2;
}

int calcula_tamanho_strlit(char * strlit){
	char* posicao_actual;
	posicao_actual = strlit;
	int tamanho_strlit = 0;

	while(*posicao_actual != '\0'){
		/* encontrou um CHRLIT */
		if(*posicao_actual == '\\'){
			posicao_actual++;
			if(*posicao_actual == 't' 
				|| *posicao_actual == 'n'
				|| *posicao_actual == '\\'
				|| *posicao_actual == '\''
				|| *posicao_actual == '\"'){
					tamanho_strlit++;
					posicao_actual++;
			}
			else if( isdigit(*posicao_actual) && check_chrlit_number(*posicao_actual) == 1  ){
				posicao_actual++;
				if( isdigit(*posicao_actual) && check_chrlit_number(*posicao_actual) == 1 ){
					posicao_actual++;
					if(isdigit(*posicao_actual) && check_chrlit_number(*posicao_actual) == 1){
						posicao_actual++;
						tamanho_strlit++;
					}else{
						tamanho_strlit++;
					}
				}else{
					tamanho_strlit++;	
				}
			}else{
				tamanho_strlit++;
			}
		}else{
			posicao_actual++;
			tamanho_strlit++;
		}

	}

	return tamanho_strlit-1; /* -2 -> aspas duplas e +1 -> \0 */

}

int check_chrlit_number(char numero){
	int i;
	i = numero - '0';
	if(i > 7)
		return -1;
	return 1;
}

char *comp_op(symbol_table *tlocal, symbol_table *tglobal, Node *node){ /*operacoes boolean, int!!*/
	cat_type(node, "int");
	add_type(tlocal, tglobal, node->child); /*sempre 2 filhos*/
	add_type(tlocal, tglobal, node->child->brother);
	return node->type;
}

char *unary_op(symbol_table *tlocal, symbol_table *tglobal, Node *node){
	cat_type(node, "int");
	add_type(tlocal, tglobal, node->child);
	return node->type;
}